# 开发说明
先安装[NodeJs](https://nodejs.org/)，然后cd到htdoc根目录，执行以下命令：

    npm install
    
完成后，页面js放在src/js下面，在htdoc根目录执行以下命令进入开发模式（会监听代码改变自动编译代码）：

    gulp
    
开发完成后，执行以下命令完成打包任务：
    
    gulp build
    
