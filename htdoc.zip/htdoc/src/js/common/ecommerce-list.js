var ecommerceList = [
    {
        name: 'Groupon',
        id:	'6ab1b8cfb8614e4daeb42de6378776ce'
    },	//Groupon
    {
        name: 'pakpobox',
        id:	'b293e018f2bb4a38bae317325d2392e9'
    },	//�ɱ�����Ӫ
    {
        name: 'popbox',
        id: 'bb41ebddceaf4d78b30e9eb0208db425'
    },	//ӡ��popbox
    {
        name: 'matahari',
        id:	'c9847b12cabd4bbcb9cc6337c123d44d'
    },	//matahari
    {
        name: 'taobao',
        id: 'd310557232c14264a3535015da3d4896'
    },	//�Ա�
    {
        name: 'yahoo',
        id: 'e4ebd7b8e21448d48cdde495f906fb10'
    },	//�Ż�
]

module.exports = ecommerceList;