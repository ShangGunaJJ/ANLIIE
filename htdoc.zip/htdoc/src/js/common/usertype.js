var userType = {
    'ROOT': 'LUserTypeRoot',
    'OPERATOR_ADMIN': 'LUserTypeOpratorAdmin',
    'OPERATOR_USER': 'LUserTypeOprator',
    'LOGISTICS_COMPANY_ADMIN': 'LUserTypeLogisticsAdmin',
    'LOGISTICS_COMPANY_USER': 'LUserTypeLogistics',
}

module.exports = userType;